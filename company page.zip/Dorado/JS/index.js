      var slides = document.querySelectorAll('.slide');
      var btns = document.querySelectorAll('.n_btn');
      let currentSlide = 1;
  
      // Javascript for image slider manual navigation
      var manualNav = function(manual){
        slides.forEach((slide) => {
          slide.classList.remove('active');
  
          btns.forEach((btn) => {
            btn.classList.remove('active');
          });
        });
  
        slides[manual].classList.add('active');
        btns[manual].classList.add('active');
      }
  
      btns.forEach((btn, currentSlide) => {
        btn.addEventListener("click", () => {
          manualNav(currentSlide);
        });
      });
  
      // Javascript for image slider autoplay navigation
      var repeat = function(activeClass){
        let active = document.getElementsByClassName('active');
        currentSlide = 1;
  
        var repeater = () => {
          setTimeout(function(){
            [...active].forEach((activeSlide) => {
              activeSlide.classList.remove('active');
            });
  
          slides[currentSlide].classList.add('active');
          btns[currentSlide].classList.add('active');
          currentSlide++;
  
          if(slides.length == currentSlide){
            currentSlide = 0;
          }
          if(currentSlide >= slides.length){
            return;
          }
          repeater();
        }, 10000);
        }
        repeater();
      }
      repeat();
      
      window.addEventListener('scroll', reveal);
  
      function reveal(){
        var reveals = document.querySelectorAll('.reveal');
  
        for(var i = 0; i < reveals.length; i++){
  
          var windowheight = window.innerHeight;
          var revealtop = reveals[i].getBoundingClientRect().top;
          var revealpoint = 150;
  
          if(revealtop < windowheight - revealpoint){
            reveals[i].classList.add('active');
          }
          else{
            reveals[i].classList.remove('active');
          }
        }
      }
